 * scales values to 8-bit if necessary */
int readpng_get_bgcolor(uch *red, uch *green, uch *blue)
{
    return 1;
}
