void
_TIFFfree(tdata_t p)
{
	free(p);
}
