static int 
t2p_mapproc(thandle_t handle, void **data, toff_t *offset) 
{ 
	(void) handle, (void) data, (void) offset;
	return -1; 
}
