tdata_t
_TIFFmalloc(tsize_t s)
{
	return (NewPtr((size_t) s));
}
